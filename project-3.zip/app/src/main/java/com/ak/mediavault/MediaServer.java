package com.ak.mediavault;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Tiny loopback HTTP server (127.0.0.1 only, secret token in the path) so WebView's real media
 * pipeline can stream video/audio with proper Range support.
 *   /TOKEN/file/{i|v|a}/ID   -> MediaStore item
 *   /TOKEN/fs?p=/abs/path    -> any file under the storage root
 */
class MediaServer {
    private final Context ctx;
    private final ServerSocket ss;
    private final String token;
    private final File root;

    MediaServer(Context c, String token, File root) throws IOException {
        this.ctx = c.getApplicationContext();
        this.token = token;
        this.root = root;
        ss = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
        Thread t = new Thread(new Runnable() {
            public void run() {
                ExecutorService ex = Executors.newCachedThreadPool();
                while (!ss.isClosed()) {
                    try {
                        final Socket s = ss.accept();
                        ex.execute(new Runnable() { public void run() { serve(s); } });
                    } catch (IOException e) { break; }
                }
                ex.shutdown();
            }
        }, "media-server");
        t.setDaemon(true);
        t.start();
    }

    String base() { return "http://127.0.0.1:" + ss.getLocalPort() + "/" + token; }

    void stop() { try { ss.close(); } catch (IOException ignored) { } }

    private static String line(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r' && sb.length() < 8192) sb.append((char) c);
        }
        return (c == -1 && sb.length() == 0) ? null : sb.toString();
    }

    private static void status(OutputStream out, String st) throws IOException {
        out.write(("HTTP/1.1 " + st + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
        out.flush();
    }

    private void serve(Socket s) {
        AssetFileDescriptor afd = null;
        FileInputStream fis = null;
        try {
            s.setSoTimeout(30000);
            InputStream in = s.getInputStream();
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 65536);
            String req = line(in);
            if (req == null) return;
            String range = null, h;
            while ((h = line(in)) != null && h.length() > 0) {
                if (h.regionMatches(true, 0, "range:", 0, 6)) range = h.substring(6).trim();
            }
            String[] p = req.split(" ");
            if (p.length < 2) { status(out, "400 Bad Request"); return; }
            boolean head = p[0].equals("HEAD");
            Uri u = Uri.parse(p[1]);
            List<String> seg = u.getPathSegments();
            if (seg.size() < 2 || !token.equals(seg.get(0))) { status(out, "403 Forbidden"); return; }

            long off = 0, len;
            String mime;
            if (seg.get(1).equals("file") && seg.size() == 4) {
                Uri base = seg.get(2).equals("v") ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        : seg.get(2).equals("a") ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                Uri item = android.content.ContentUris.withAppendedId(base, Long.parseLong(seg.get(3)));
                afd = ctx.getContentResolver().openAssetFileDescriptor(item, "r");
                if (afd == null) { status(out, "404 Not Found"); return; }
                fis = afd.createInputStream();
                off = afd.getStartOffset();
                len = afd.getLength();
                if (len < 0) len = afd.getParcelFileDescriptor().getStatSize();
                mime = ctx.getContentResolver().getType(item);
            } else if (seg.get(1).equals("fs")) {
                String q = u.getQueryParameter("p");
                File f = q == null ? null : new File(q).getCanonicalFile();
                if (f == null || !f.isFile() || !f.getPath().startsWith(root.getCanonicalPath())) {
                    status(out, "404 Not Found"); return;
                }
                fis = new FileInputStream(f);
                len = f.length();
                String ext = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(f).toString());
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext == null ? "" : ext.toLowerCase());
            } else { status(out, "404 Not Found"); return; }
            if (mime == null) mime = "application/octet-stream";

            long start = 0, end = len - 1;
            boolean partial = false;
            if (range != null && range.startsWith("bytes=") && len > 0) {
                try {
                    String[] ab = range.substring(6).split(",")[0].trim().split("-", -1);
                    if (ab[0].length() > 0) {
                        start = Long.parseLong(ab[0]);
                        if (ab.length > 1 && ab[1].length() > 0) end = Long.parseLong(ab[1]);
                    } else if (ab.length > 1 && ab[1].length() > 0) {
                        start = Math.max(0, len - Long.parseLong(ab[1]));
                    }
                    if (end >= len) end = len - 1;
                    if (start > end) {
                        out.write(("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + len
                                + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
                        out.flush();
                        return;
                    }
                    partial = true;
                } catch (NumberFormatException e) { start = 0; end = len - 1; partial = false; }
            }
            long count = Math.max(0, end - start + 1);
            out.write(("HTTP/1.1 " + (partial ? "206 Partial Content" : "200 OK")
                    + "\r\nContent-Type: " + mime + "\r\nAccept-Ranges: bytes\r\nContent-Length: " + count
                    + (partial ? "\r\nContent-Range: bytes " + start + "-" + end + "/" + len : "")
                    + "\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
            if (!head && count > 0) {
                fis.getChannel().position(off + start);
                byte[] buf = new byte[65536];
                long left = count;
                while (left > 0) {
                    int n = fis.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) break;
                    out.write(buf, 0, n);
                    left -= n;
                }
            }
            out.flush();
        } catch (Exception ignored) {
            // client closed the connection (normal while seeking)
        } finally {
            try { if (fis != null) fis.close(); } catch (IOException ignored) { }
            try { if (afd != null) afd.close(); } catch (IOException ignored) { }
            try { s.close(); } catch (IOException ignored) { }
        }
    }
}
