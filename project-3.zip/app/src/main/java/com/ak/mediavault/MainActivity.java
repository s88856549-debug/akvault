package com.ak.mediavault;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.MimeTypeMap;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Comparator;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * AK MEDIA VAULT - native shell.
 * The UI is assets/index.html served from https://ak.local/ . The page reads the phone's
 * photos / videos / audio through three virtual endpoints answered here (no real network):
 *   /api/media        -> JSON list of everything in MediaStore
 *   /thumb/{i|v|a}/ID -> JPEG thumbnail
 *   /file/{i|v|a}/ID  -> the file itself (with Range support so video seeking works)
 */
public class MainActivity extends Activity {
    private static final String HOST = "ak.local";
    private static final int REQ_PERM = 11, REQ_FILE = 12;

    private MediaServer server;
    private WebView web;
    private FrameLayout root;
    private ValueCallback<Uri[]> chooserCb;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#241711"));
        w.setNavigationBarColor(Color.parseColor("#1c120d"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#241711"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#241711"));
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        try {
            byte[] r = new byte[16];
            new SecureRandom().nextBytes(r);
            StringBuilder t = new StringBuilder();
            for (byte x : r) t.append(String.format("%02x", x));
            server = new MediaServer(this, t.toString(), Environment.getExternalStorageDirectory());
        } catch (IOException e) { server = null; }
        web.addJavascriptInterface(new Bridge(), "AK");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return handle(r);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    List<String> types = new ArrayList<>();
                    String[] acc = p.getAcceptTypes();
                    if (acc != null) for (String t : acc) if (t != null && t.contains("/")) types.add(t);
                    if (!types.isEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    startActivityForResult(Intent.createChooser(i, "ফাইল বেছে নাও"), REQ_FILE);
                } catch (Exception e) {
                    chooserCb = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }

            // fullscreen button on <video>
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCb = cb;
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }

            @Override public void onHideCustomView() { hideCustom(); }
        });

        if (!hasPerm()) askPermission();
        web.loadUrl("https://" + HOST + "/index.html");
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    // ------------------------------------------------------------------ permissions
    private String[] permList() {
        return Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO}
                : new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    private boolean allFiles() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasPerm() {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true;
        for (String p : permList()) if (checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) return true;
        return false;
    }

    private void askPermission() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> need = new ArrayList<>();
        for (String p : permList()) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        reloadMedia();
    }

    @Override protected void onResume() {
        super.onResume();
        reloadMedia(); // e.g. user just came back from system Settings
    }

    private void reloadMedia() {
        if (web != null) web.evaluateJavascript("window.akReload&&window.akReload()", null);
    }

    /** Methods the page can call as window.AK.xxx() */
    public class Bridge {
        @JavascriptInterface public boolean hasPermission() { return hasPerm(); }
        @JavascriptInterface public boolean hasAllFiles() { return allFiles(); }
        @JavascriptInterface public String mediaBase() { return server == null ? "" : server.base(); }
        @JavascriptInterface public String root() { return Environment.getExternalStorageDirectory().getAbsolutePath(); }

        @JavascriptInterface public void requestAllFiles() {
            runOnUiThread(new Runnable() { public void run() {
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                    }
                } else askPermission();
            } });
        }

        /** JSON: {"path":..., "items":[[name,isDir,sizeOrCount,mtimeSec],...]} or {"err":1} */
        @JavascriptInterface public String listDir(String path) {
            try {
                File rt = Environment.getExternalStorageDirectory().getCanonicalFile();
                File d = new File(path).getCanonicalFile();
                if (!d.getPath().startsWith(rt.getPath()) || !d.isDirectory()) return "{\"err\":1}";
                File[] fs = d.listFiles();
                JSONArray a = new JSONArray();
                if (fs != null) {
                    Arrays.sort(fs, new Comparator<File>() {
                        public int compare(File x, File y) {
                            if (x.isDirectory() != y.isDirectory()) return x.isDirectory() ? -1 : 1;
                            return x.getName().compareToIgnoreCase(y.getName());
                        }
                    });
                    for (File f : fs) {
                        JSONArray r = new JSONArray();
                        String[] sub = f.isDirectory() ? f.list() : null;
                        r.put(f.getName()).put(f.isDirectory())
                                .put(f.isDirectory() ? (sub == null ? 0 : sub.length) : f.length())
                                .put(f.lastModified() / 1000);
                        a.put(r);
                    }
                }
                JSONObject o = new JSONObject();
                o.put("path", d.getPath());
                o.put("items", a);
                return o.toString();
            } catch (Exception e) { return "{\"err\":1}"; }
        }

        @JavascriptInterface public void openExternal(final String path) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    File f = new File(path);
                    Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                    String ext = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(f).toString());
                    String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext == null ? "" : ext.toLowerCase());
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, m == null ? "*/*" : m);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Open with"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "এই ফাইল খোলার অ্যাপ নেই", Toast.LENGTH_SHORT).show();
                }
            } });
        }

        /** true = immersive full screen + keep screen on (video player) */
        @JavascriptInterface public void fullscreen(final boolean on) {
            runOnUiThread(new Runnable() { public void run() {
                web.setKeepScreenOn(on);
                getWindow().getDecorView().setSystemUiVisibility(on
                        ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        : View.SYSTEM_UI_FLAG_VISIBLE);
            } });
        }

        /** "land" | "port" | anything else = follow the phone's sensor */
        @JavascriptInterface public void orient(final String m) {
            runOnUiThread(new Runnable() { public void run() {
                setRequestedOrientation(m.equals("land") ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        : m.equals("port") ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                        : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            } });
        }

        @JavascriptInterface public void requestPermission() {
            runOnUiThread(new Runnable() { public void run() { askPermission(); } });
        }

        @JavascriptInterface public void openSettings() {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            });
        }
    }

    // ------------------------------------------------------------------ virtual server
    private WebResourceResponse handle(WebResourceRequest r) {
        Uri u = r.getUrl();
        if (u == null || !HOST.equals(u.getHost())) return null;
        String path = u.getPath() == null ? "/" : u.getPath();
        try {
            if (path.equals("/") || path.equals("/index.html")) {
                return plain("text/html", assetBytes("index.html"));
            }
            if (path.equals("/api/media")) {
                return plain("application/json", mediaJson().getBytes("UTF-8"));
            }
            String[] p = path.split("/");            // ["", "thumb", "i", "123"]
            if (p.length == 4 && (p[1].equals("thumb") || p[1].equals("file"))) {
                Uri uri = itemUri(p[2], Long.parseLong(p[3]));
                if (uri == null) return notFound();
                if (p[1].equals("thumb")) return thumb(p[2], Long.parseLong(p[3]), uri);
                Map<String, String> h = r.getRequestHeaders();
                String range = h == null ? null : h.get("Range");
                if (range == null && h != null) range = h.get("range");
                return serveFile(uri, range);
            }
        } catch (Exception e) {
            return notFound();
        }
        return notFound();
    }

    private Map<String, String> baseHeaders() {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-store");
        return h;
    }

    private WebResourceResponse plain(String mime, byte[] data) {
        WebResourceResponse r = new WebResourceResponse(mime, "UTF-8", new ByteArrayInputStream(data));
        r.setResponseHeaders(baseHeaders());
        return r;
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", baseHeaders(),
                new ByteArrayInputStream(new byte[0]));
    }

    private byte[] assetBytes(String name) throws IOException {
        InputStream in = getAssets().open(name);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    private Uri itemUri(String type, long id) {
        Uri base;
        if (type.equals("i")) base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        else if (type.equals("v")) base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        else if (type.equals("a")) base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        else return null;
        return ContentUris.withAppendedId(base, id);
    }

    @SuppressWarnings("deprecation")
    private WebResourceResponse thumb(String type, long id, Uri uri) {
        Bitmap bm = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                bm = getContentResolver().loadThumbnail(uri, new Size(360, 360), null);
            } else if (type.equals("i")) {
                bm = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id,
                        MediaStore.Images.Thumbnails.MINI_KIND, null);
            } else if (type.equals("v")) {
                bm = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            }
        } catch (Exception e) {
            bm = null;
        }
        if (bm == null) return notFound();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 82, out);
        Map<String, String> h = baseHeaders();
        h.put("Cache-Control", "max-age=86400");
        WebResourceResponse r = new WebResourceResponse("image/jpeg", null, new ByteArrayInputStream(out.toByteArray()));
        r.setResponseHeaders(h);
        return r;
    }

    /** Streams a MediaStore item; answers "Range: bytes=a-b" with 206 so video can seek. */
    private WebResourceResponse serveFile(Uri uri, String range) throws IOException {
        ContentResolver cr = getContentResolver();
        AssetFileDescriptor afd = cr.openAssetFileDescriptor(uri, "r");
        if (afd == null) return notFound();
        long len = afd.getLength();
        if (len < 0) len = afd.getParcelFileDescriptor().getStatSize();
        String mime = cr.getType(uri);
        if (mime == null) mime = "application/octet-stream";

        long start = 0, end = len - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=") && len > 0) {
            try {
                String[] ab = range.substring(6).split(",")[0].trim().split("-", -1);
                if (ab[0].length() > 0) {
                    start = Long.parseLong(ab[0]);
                    if (ab.length > 1 && ab[1].length() > 0) end = Long.parseLong(ab[1]);
                } else if (ab.length > 1 && ab[1].length() > 0) {   // suffix range "-N"
                    start = Math.max(0, len - Long.parseLong(ab[1]));
                }
                if (end >= len) end = len - 1;
                if (start > end) { start = 0; end = len - 1; } else partial = true;
            } catch (NumberFormatException e) {
                start = 0; end = len - 1; partial = false;
            }
        }
        FileInputStream fis = afd.createInputStream();
        if (start > 0) fis.getChannel().position(afd.getStartOffset() + start);
        long count = end - start + 1;
        InputStream body = new Limited(fis, count);

        Map<String, String> h = baseHeaders();
        h.put("Accept-Ranges", "bytes");
        h.put("Content-Length", String.valueOf(count));
        if (partial) {
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
            return new WebResourceResponse(mime, null, 206, "Partial Content", h, body);
        }
        return new WebResourceResponse(mime, null, 200, "OK", h, body);
    }

    private static class Limited extends FilterInputStream {
        private long left;
        Limited(InputStream in, long n) { super(in); left = n; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int c = super.read();
            if (c >= 0) left--;
            return c;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }
    }

    // ------------------------------------------------------------------ media list
    /**
     * { "perm":true, "total":bytes, "free":bytes,
     *   "items":[ [type,id,name,size,dateAdded,bucket,mime,durationMs], ... ] }
     */
    private String mediaJson() {
        boolean perm = hasPerm();
        StringBuilder sb = new StringBuilder(perm ? 1 << 16 : 128);
        long total = 0, free = 0;
        try {
            StatFs fs = new StatFs(Environment.getExternalStorageDirectory().getPath());
            total = fs.getTotalBytes();
            free = fs.getAvailableBytes();
        } catch (Exception ignored) { }
        sb.append("{\"perm\":").append(perm).append(",\"total\":").append(total)
                .append(",\"free\":").append(free).append(",\"items\":[");
        if (perm) {
            int[] n = {0};
            query(sb, n, "i", MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null);
            query(sb, n, "v", MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Video.Media.DURATION);
            query(sb, n, "a", MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.DURATION);
        }
        sb.append("]}");
        return sb.toString();
    }

    @SuppressWarnings("deprecation")
    private void query(StringBuilder sb, int[] count, String type, Uri collection, String durCol) {
        List<String> cols = new ArrayList<>();
        cols.add(MediaStore.MediaColumns._ID);
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME);
        cols.add(MediaStore.MediaColumns.SIZE);
        cols.add(MediaStore.MediaColumns.DATE_ADDED);
        cols.add(MediaStore.MediaColumns.MIME_TYPE);
        boolean hasBucket = Build.VERSION.SDK_INT >= 29;
        cols.add(hasBucket ? MediaStore.MediaColumns.BUCKET_DISPLAY_NAME : MediaStore.MediaColumns.DATA);
        if (durCol != null) cols.add(durCol);

        String sel = null;
        if (type.equals("a")) {
            sel = MediaStore.Audio.Media.IS_RINGTONE + "=0 AND " + MediaStore.Audio.Media.IS_NOTIFICATION
                    + "=0 AND " + MediaStore.Audio.Media.IS_ALARM + "=0";
        }
        Cursor c = null;
        try {
            c = getContentResolver().query(collection, cols.toArray(new String[0]), sel, null,
                    MediaStore.MediaColumns.DATE_ADDED + " DESC");
            if (c == null) return;
            while (c.moveToNext()) {
                if (count[0]++ > 0) sb.append(',');
                String bucket = c.getString(5);
                if (!hasBucket && bucket != null) {            // derive folder name from path
                    int s = bucket.lastIndexOf('/');
                    if (s > 0) {
                        int s2 = bucket.lastIndexOf('/', s - 1);
                        bucket = bucket.substring(s2 + 1, s);
                    }
                }
                sb.append('[').append(JSONObject.quote(type)).append(',')
                        .append(c.getLong(0)).append(',')
                        .append(JSONObject.quote(c.getString(1) == null ? "" : c.getString(1))).append(',')
                        .append(c.getLong(2)).append(',')
                        .append(c.getLong(3)).append(',')
                        .append(JSONObject.quote(bucket == null ? "" : bucket)).append(',')
                        .append(JSONObject.quote(c.getString(4) == null ? "" : c.getString(4))).append(',')
                        .append(durCol != null ? c.getLong(6) : 0).append(']');
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
    }

    // ------------------------------------------------------------------ misc
    @Override protected void onActivityResult(int rc, int res, Intent d) {
        if (rc == REQ_FILE && chooserCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && d != null) {
                if (d.getClipData() != null) {
                    int n = d.getClipData().getItemCount();
                    r = new Uri[n];
                    for (int i = 0; i < n; i++) r[i] = d.getClipData().getItemAt(i).getUri();
                } else if (d.getData() != null) r = new Uri[]{d.getData()};
            }
            chooserCb.onReceiveValue(r);
            chooserCb = null;
        } else super.onActivityResult(rc, res, d);
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        // let the page handle Back first (close viewer, leave folder, go Home)
        web.evaluateJavascript("(window.akBack?window.akBack():false)", new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                if (!"true".equals(v)) finish();
            }
        });
    }

    @Override protected void onDestroy() {
        if (server != null) server.stop();
        if (web != null) { root.removeView(web); web.destroy(); }
        super.onDestroy();
    }
}
